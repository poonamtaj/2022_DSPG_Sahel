=====
Usage
=====

To use geemap in a project::

    import geemap
