# colormaps module

::: geemap.colormaps