# chart module

::: geemap.chart
