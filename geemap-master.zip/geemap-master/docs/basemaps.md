# basemaps module

::: geemap.basemaps