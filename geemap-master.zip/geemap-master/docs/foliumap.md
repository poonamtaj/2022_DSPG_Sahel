# foliumap module

::: geemap.foliumap
