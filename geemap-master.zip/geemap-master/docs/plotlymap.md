# plotlymap module

::: geemap.plotlymap