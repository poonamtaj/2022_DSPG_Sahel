# legends module

::: geemap.legends