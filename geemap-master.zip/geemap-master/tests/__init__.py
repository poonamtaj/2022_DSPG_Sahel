"""Unit test package for geemap."""
